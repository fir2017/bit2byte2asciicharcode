﻿namespace bit2char2byte
{
    partial class bytecontrol
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.bit8 = new bit2char2byte.bit();
            this.bit7 = new bit2char2byte.bit();
            this.bit6 = new bit2char2byte.bit();
            this.bit5 = new bit2char2byte.bit();
            this.bit4 = new bit2char2byte.bit();
            this.bit3 = new bit2char2byte.bit();
            this.bit2 = new bit2char2byte.bit();
            this.bit1 = new bit2char2byte.bit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label1.Location = new System.Drawing.Point(202, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 15);
            this.label1.TabIndex = 8;
            this.label1.Text = "00000000";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label2.Location = new System.Drawing.Point(265, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 15);
            this.label2.TabIndex = 9;
            this.label2.Text = "                        ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label3.Location = new System.Drawing.Point(352, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "                        ";
            // 
            // bit8
            // 
            this.bit8.BackColor = System.Drawing.Color.White;
            this.bit8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bit8.Location = new System.Drawing.Point(178, 3);
            this.bit8.Name = "bit8";
            this.bit8.Size = new System.Drawing.Size(18, 34);
            this.bit8.TabIndex = 7;
            // 
            // bit7
            // 
            this.bit7.BackColor = System.Drawing.Color.White;
            this.bit7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bit7.Location = new System.Drawing.Point(153, 3);
            this.bit7.Name = "bit7";
            this.bit7.Size = new System.Drawing.Size(18, 34);
            this.bit7.TabIndex = 6;
            // 
            // bit6
            // 
            this.bit6.BackColor = System.Drawing.Color.White;
            this.bit6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bit6.Location = new System.Drawing.Point(128, 3);
            this.bit6.Name = "bit6";
            this.bit6.Size = new System.Drawing.Size(18, 34);
            this.bit6.TabIndex = 5;
            // 
            // bit5
            // 
            this.bit5.BackColor = System.Drawing.Color.White;
            this.bit5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bit5.Location = new System.Drawing.Point(103, 3);
            this.bit5.Name = "bit5";
            this.bit5.Size = new System.Drawing.Size(18, 34);
            this.bit5.TabIndex = 4;
            // 
            // bit4
            // 
            this.bit4.BackColor = System.Drawing.Color.White;
            this.bit4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bit4.Location = new System.Drawing.Point(78, 3);
            this.bit4.Name = "bit4";
            this.bit4.Size = new System.Drawing.Size(18, 34);
            this.bit4.TabIndex = 3;
            // 
            // bit3
            // 
            this.bit3.BackColor = System.Drawing.Color.White;
            this.bit3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bit3.Location = new System.Drawing.Point(53, 3);
            this.bit3.Name = "bit3";
            this.bit3.Size = new System.Drawing.Size(18, 34);
            this.bit3.TabIndex = 2;
            // 
            // bit2
            // 
            this.bit2.BackColor = System.Drawing.Color.White;
            this.bit2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bit2.Location = new System.Drawing.Point(28, 3);
            this.bit2.Name = "bit2";
            this.bit2.Size = new System.Drawing.Size(18, 34);
            this.bit2.TabIndex = 1;
            // 
            // bit1
            // 
            this.bit1.BackColor = System.Drawing.Color.White;
            this.bit1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.bit1.Location = new System.Drawing.Point(3, 3);
            this.bit1.Name = "bit1";
            this.bit1.Size = new System.Drawing.Size(18, 34);
            this.bit1.TabIndex = 0;
            // 
            // bytecontrol
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.bit8);
            this.Controls.Add(this.bit7);
            this.Controls.Add(this.bit6);
            this.Controls.Add(this.bit5);
            this.Controls.Add(this.bit4);
            this.Controls.Add(this.bit3);
            this.Controls.Add(this.bit2);
            this.Controls.Add(this.bit1);
            this.Name = "bytecontrol";
            this.Size = new System.Drawing.Size(451, 41);
            this.Load += new System.EventHandler(this.bytecontrol_Load);
            this.Click += new System.EventHandler(this.bytecontrol_Click);
            this.Enter += new System.EventHandler(this.bytecontrol_Enter);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.bytecontrol_MouseMove);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private bit bit1;
        private bit bit2;
        private bit bit3;
        private bit bit4;
        private bit bit5;
        private bit bit6;
        private bit bit7;
        private bit bit8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}
